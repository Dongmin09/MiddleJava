package board.dao;

import java.util.List;

import board.vo.BoardVO;

public interface IBoardDAO {

	public int insertBoard(BoardVO vo);
	
	public int updateBoard(BoardVO vo);
	
	public int deleteBoard(int no);
	
	public List<BoardVO> getAllBoardList();
	
	public List<BoardVO> searchBoardList(BoardVO vo);

}

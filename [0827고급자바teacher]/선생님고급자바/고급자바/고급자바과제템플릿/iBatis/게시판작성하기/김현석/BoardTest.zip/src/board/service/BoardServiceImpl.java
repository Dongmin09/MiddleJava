package board.service;

import java.util.List;

import board.dao.BoardDAOImpl;
import board.dao.IBoardDAO;
import board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService{
	
	private static IBoardService bdService;
	
	private IBoardDAO bdDao;
	
	private BoardServiceImpl() {
		bdDao = BoardDAOImpl.getInstance();
	}
	
	public static IBoardService getInstance() {
		if(bdService == null) {
			bdService = new BoardServiceImpl();
		}
		return bdService;
	}
	
	@Override
	public int registerBoard(BoardVO vo) {
		int cnt = bdDao.insertBoard(vo);
		return cnt;
	}


	@Override
	public int modifyBoard(BoardVO vo) {
		int cnt = bdDao.updateBoard(vo);
		return cnt;
	}

	@Override
	public int removeBoard(int no) {
		int cnt = bdDao.deleteBoard(no);
		return cnt;
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		
		List<BoardVO> bdList = bdDao.getAllBoardList();
		
		return bdList;
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO vo) {
		List<BoardVO> bdList = bdDao.searchBoardList(vo);
		return bdList;
	}


}

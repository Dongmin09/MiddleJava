package util;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * SqlSession 객체를 제공하기 위한 유틸클래스
 * 
 * @author PC-06
 * 자바는 jdbc api를 제공해주지만 이런 jdbc를 이용하면 1개 클래스에 반복된 코드가 존재하므로
 * 유지 보수,및 재사용성 등이 안좋아지는 단점이 존재 / mybatis를 이용하면 자바의 관계형 데이터
 * 베이스 프로그래밍을 좀더 쉽게 할수 있게 도와주는 개발 프레임워크이다.
 */
public class MyBatisUtil {

	private static SqlSessionFactory sessionFactory;

	static {

		try {

			// 1-1. xml설정문서 읽어오기
			// 설정파일의 인코딩정보 설정(한글처리를 위해서...)
			Charset charset = Charset.forName("UTF-8");
			Resources.setCharset(charset);
			Reader rd = Resources.getResourceAsReader("config/mybatis-config.xml");

			// 1-2. 위에서 읽어온 Reader 객체를 이용하여 실제 작업을 진행할 개체 생성하기
			sessionFactory = new SqlSessionFactoryBuilder().build(rd);

			rd.close(); // 자원반납

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * SqlSession 객체를 제공하는 팩토리 메서드
	 * SqlSessionFactory는 SqlSession인스턴스를 생성하기 위해 사용할수 있는 6개의 메소드
	 * 가지고 있다. 그중 openSession()과 openSession(boolean autoCommit)이 있다. 있다.
	 * @return SqlSession 객체
	 */
	public static SqlSession getInstance() {
		return sessionFactory.openSession();
	}
	
	/**
	 * SqlSession 객체를 제공하는 팩토리 메서드
	 * @param autoCommit 오토커밋 여부
	 * @return SqlSession 객체
	 */
	public static SqlSession getInstance(boolean autoCommit) {
		return sessionFactory.openSession(autoCommit);
	}
	
	

}

package boardmain;

import java.util.List;
import java.util.Scanner;

import board.service.BoardServiceImpl;
import board.service.IBoardService;
import board.vo.BoardVO;

public class BoardMain {
	private Scanner scan = new Scanner(System.in);
	private IBoardService bdService;

	public BoardMain() {
		bdService = BoardServiceImpl.getInstance();
	}

	public void displayMenu() {
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 전체 목록 출력");
		System.out.println("  2. 새글 작성");
		System.out.println("  3. 수정");
		System.out.println("  4. 삭제");
		System.out.println("  5. 검색.");
		System.out.println("  6. 작업 끝.");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}

	public void start() {
		int choice;
		do {
			displayMenu(); // 메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch (choice) {
			case 1: // 전체 목록 출력
				displayBoardAll();
				break;
			case 2: // 새글 작성
				insertBoard();
				break;
			case 3: // 수정
				updateBoard();
				break;
			case 4: // 삭제
				deleteBoard();
				break;
			case 5: // 검색
				searchBoard();
				break;
			case 6: // 작업 끝
				System.out.println("작업을 마칩니다.");
				break;
			default:
				System.out.println("번호를 잘못 입력했습니다. 다시 입력하세요");
			}
		} while (choice != 6);
	}

	// 정보 검색 메서드
	private void searchBoard() {
		scan.nextLine(); // 입력 버퍼 비우기
		System.out.println();
		System.out.println("검색할 게시판을 입력하세요.");

		System.out.print("게시판 번호 >> ");
		int no = Integer.parseInt(scan.nextLine());

		System.out.print("게시판 제목 >> ");
		String title = scan.nextLine().trim();

		System.out.print("게시판 작성자 >> ");
		String writer = scan.nextLine().trim();

		System.out.print("게시판 내용 >> ");
		String content = scan.nextLine().trim();

		BoardVO vo = new BoardVO();
		vo.setNo(no);
		vo.setTitle(title);
		vo.setWriter(writer);
		vo.setContent(content);

		List<BoardVO> bdList = bdService.searchBoardList(vo);

		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println(" 번호\t제 목\t작성자\t작성날짜\t내용");
		System.out.println("-----------------------------------------");

		if (bdList.size() == 0) {
			System.out.println(" 검색된 게시판정보가 없습니다.");
		} else {
			for (BoardVO vo2 : bdList) {
				System.out.println(
						vo2.getNo() + "\t" + vo2.getTitle() + "\t" + vo2.getWriter() + "\t" + vo2.getContent());
			}
		}
		System.out.println("-----------------------------------------");
		System.out.println("검색 끝.");
	}

	// 전체 목록 출력
	private void displayBoardAll() {
		System.out.println();
		System.out.println("-----------------------------------------");
		System.out.println(" 번호\t제 목\t작성자\t작성날짜\t내용");
		System.out.println("-----------------------------------------");

		List<BoardVO> bdList = bdService.getAllBoardList();

		if (bdList.size() == 0) {
			System.out.println(" 게시판 정보가 없습니다.");
		} else {
			for (BoardVO vo : bdList) {
				System.out.println(vo.getNo() + "\t" + vo.getTitle() + "\t" + vo.getWriter() + "\t" + vo.getContent());
			}
		}
		System.out.println("-----------------------------------------");
		System.out.println("출력 끝.");
	}

	// 업데이트 메서드
	private void updateBoard() {

		System.out.print("게시글 번호>> ");
		int no = scan.nextInt();
		
		System.out.print("제목 >> ");
		String title = scan.next();

		scan.nextLine(); // next로 받다가 Line으로 받을때는 쓰레기버퍼를 처리해줘야함

		System.out.print("내용 >> ");
		String content = scan.nextLine();

		BoardVO vo = new BoardVO();
		vo.setTitle(title);
		vo.setContent(content);
		vo.setNo(no);

		int cnt = bdService.modifyBoard(vo);

		if (cnt > 0) {
			System.out.println(no + "번 게시판 정보 수정 성공!");
		} else {
			System.out.println(no + "번 게시판 정보 수정 실패!!!");
		}
	}

	private void deleteBoard() {
		System.out.println();
		System.out.println("삭제할 게시판을 입력하세요.");
		System.out.print("게시판번호 >> ");

		int no = scan.nextInt();

		int cnt = bdService.removeBoard(no);

		if (cnt > 0) {
			System.out.println(no + "번 게시판 삭제 성공!");
		} else {
			System.out.println(no + "번 게시판 삭제 실패!!!");
		}
	}

	private void insertBoard() {

		String title = "";

		System.out.println();
		System.out.println("추가할 게시글을 입력하세요.");
		System.out.print("제목 >> ");

		title = scan.next();


		System.out.print("작성자 >> ");
		String writer = scan.next();

		scan.nextLine(); // next로 받다가 Line으로 받을때는 쓰레기버퍼를 처리해줘야함

		System.out.print("내용 >> ");
		String content = scan.nextLine();

		BoardVO vo = new BoardVO();
		vo.setTitle(title);
		vo.setWriter(writer);
		vo.setContent(content);

		int cnt = bdService.registerBoard(vo);

		if (cnt > 0) {
			System.out.println(writer + " 게시글 등록 성공!");
		} else {
			System.out.println(writer + " 게시글 등록 실패!!!");
		}
	}


	public static void main(String[] args) {
		BoardMain bdObj = new BoardMain();
		bdObj.start();
	}

}

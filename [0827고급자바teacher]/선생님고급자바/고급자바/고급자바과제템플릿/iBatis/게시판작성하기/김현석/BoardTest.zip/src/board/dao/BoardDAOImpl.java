package board.dao;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import board.vo.BoardVO;
import util.MyBatisUtil;

public class BoardDAOImpl implements IBoardDAO {
	
	private static IBoardDAO bdDao;
	
	private SqlSession sqlSession;
	
	private BoardDAOImpl() {
		sqlSession = MyBatisUtil.getInstance(true);
	}
	
	public static IBoardDAO getInstance() {
		if(bdDao == null) {
			bdDao = new BoardDAOImpl();
		}
		return bdDao;
	}
	@Override
	public int insertBoard(BoardVO vo) {
		
		int cnt = sqlSession.insert("board.insertBoard", vo);
		
		return cnt;
	}


	@Override
	public int updateBoard(BoardVO vo) {
		
		int cnt = sqlSession.update("board.updateBoard",vo);
		
		return cnt;
	}

	@Override
	public int deleteBoard(int no) {
		
		int cnt = sqlSession.delete("board.deleteBoard",no);
		
		return cnt;
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		
		List<BoardVO> bdList = sqlSession.selectList("board.boardAllList");
		
		return bdList;
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO vo) {
		
		List<BoardVO> bdList = sqlSession.selectList("board.searchBoardList",vo);
		
		return bdList;
	}

	
}

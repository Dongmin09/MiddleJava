package board.service;

import java.util.List;

import board.vo.BoardVO;

public interface IBoardService {
	
	
	public int registerBoard(BoardVO vo);
	
	public int modifyBoard(BoardVO vo);
	
	public int removeBoard(int no);
	
	public List<BoardVO> getAllBoardList();
	
	public List<BoardVO> searchBoardList(BoardVO vo);
}

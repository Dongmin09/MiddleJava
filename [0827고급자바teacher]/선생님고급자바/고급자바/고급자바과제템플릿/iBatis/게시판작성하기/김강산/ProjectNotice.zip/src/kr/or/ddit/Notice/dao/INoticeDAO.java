package kr.or.ddit.Notice.dao;

import java.util.List;

import kr.or.ddit.Notice.vo.NoticeVO;

public interface INoticeDAO {

	public int insertBoard(NoticeVO nv);
	
	public boolean checkBoard(String boardNo);
	
	public int updateBoard(NoticeVO nv);
	
	public int deleteBoard(String boardNo);
	
	public List<NoticeVO>getAllBoardList();
	
	public List<NoticeVO>searchBoardList(NoticeVO nv);
}

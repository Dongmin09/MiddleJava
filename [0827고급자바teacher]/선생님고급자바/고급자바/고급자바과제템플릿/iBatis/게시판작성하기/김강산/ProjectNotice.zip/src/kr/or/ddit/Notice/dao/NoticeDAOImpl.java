package kr.or.ddit.Notice.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.Notice.vo.NoticeVO;
import kr.or.ddit.util.MyBatisUtil;
import sun.security.jca.GetInstance;

public class NoticeDAOImpl implements INoticeDAO {
	
	private static INoticeDAO notiDao;
	
	private SqlSession sqlSession;
	
	public NoticeDAOImpl() {
		sqlSession = MyBatisUtil.getInstance(true);
	}
	
	public static INoticeDAO getInstance() {
		if(notiDao == null) {
			notiDao = new NoticeDAOImpl();
		}
		return notiDao;
	}

	@Override
	public int insertBoard(NoticeVO nv) {
		int cnt = sqlSession.insert("board.insertBoard", nv);
		return cnt;
	}

	@Override
	public boolean checkBoard(String boardNo) {
		boolean chk = false;
		int cnt = sqlSession.selectOne("board.checkBoard", boardNo);
		if(cnt>0) {
			chk = true;
		}
		return chk;
	}

	@Override
	public int updateBoard(NoticeVO nv) {
		int cnt = sqlSession.update("board.updateBoard", nv);
		return cnt;
	}

	@Override
	public int deleteBoard(String boardNo) {
		int cnt = sqlSession.delete("board.deleteBoard", boardNo);
		return cnt;
	}

	@Override
	public List<NoticeVO> getAllBoardList() {
		List<NoticeVO> notiList = sqlSession.selectList("board.boardAllList");
		return notiList;
	}

	@Override
	public List<NoticeVO> searchBoardList(NoticeVO nv) {
		List<NoticeVO> notiList = sqlSession.selectList("board.searchBoardList", nv);
		return notiList;
	};
}

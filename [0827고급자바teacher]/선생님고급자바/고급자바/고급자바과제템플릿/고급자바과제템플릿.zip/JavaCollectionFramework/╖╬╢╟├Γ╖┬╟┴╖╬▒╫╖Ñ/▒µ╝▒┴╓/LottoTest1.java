package kr.or.ddit.basic;

public class LottoTest1 {
	public static void main(String[] args) {
		new Lotto().menu();
	}

}

import java.util.Comparator;

public class ComparatorStudent implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		int result = 1;
		if(o1.getTotal()>=o2.getTotal()) {
			result =-1;
		}
		return result;
	}

}


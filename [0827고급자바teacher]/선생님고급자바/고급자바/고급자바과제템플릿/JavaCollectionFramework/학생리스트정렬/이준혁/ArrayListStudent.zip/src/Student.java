import java.util.List;

public class Student implements Comparable<Student>{
	private String studentNo;
	private String studentNm;
	private int korSc;
	private int engSc;
	private int mathSc;
	private int total;
	private int rank;
	
	public Student(String studentNo, String studentNm, int korSc, int engSc, int mathSc) {
		this.studentNo = studentNo;
		this.studentNm = studentNm;
		this.korSc = korSc;
		this.engSc = engSc;
		this.mathSc = mathSc;
		this.total = korSc+engSc+mathSc;
	}

	public int getRank() {
		return rank;
	}



	public void setRank(int rank) {
		this.rank = rank;
	}

	public String getStudentNm() {
		return studentNm;
	}

	public void setStudentNm(String studentNm) {
		this.studentNm = studentNm;
	}

	public int getKorSc() {
		return korSc;
	}

	public void setKorSc(int korSc) {
		this.korSc = korSc;
	}

	public int getEngSc() {
		return engSc;
	}

	public void setEngSc(int engSc) {
		this.engSc = engSc;
	}

	public int getMathSc() {
		return mathSc;
	}

	public void setMathSc(int mathSc) {
		this.mathSc = mathSc;
	}
	public int getTotal() {
		return total;
	}
	
	public void show() {
		System.out.print("학번: "+studentNo);
		System.out.print(" \t이름: "+studentNm);
		System.out.print(" \t한국어점수: "+korSc);
		System.out.print(" \t영어점수 : "+ engSc);
		System.out.print(" \t수학점수: "+mathSc);
		System.out.println("\t토탈: "+total);
	}
	@Override
	public String toString() {
		return "Student [studentNm=" + studentNm + ", korSc=" + korSc + ", engSc=" + engSc + ", mathSc=" + mathSc
				+ ", total=" + total + "]";
	}

	public String getStudentNo() {
		return studentNo;
	}
	
	public void setStudentNo(String studentNo) {
		this.studentNo = studentNo;
	}
	
	@Override
	public int compareTo(Student st) {
		return this.getStudentNo().compareTo(st.getStudentNo());
	}
}

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class SortStudent {
	public static void main(String[] args) {
		Random random = new Random();
		List<Student> list = new ArrayList<Student>();
		int sc = random.nextInt(100)+1;
		list.add(new Student("1","이준혁",sc,sc,sc)); 
		list.add(new Student("3","김강산",sc,sc,sc)); 
		list.add(new Student("5","홍길동",sc,sc,sc)); 
		 
		list.add(new Student("2","허지현",random.nextInt(100)+1,random.nextInt(100)+1,random.nextInt(100)+1)); 
		list.add(new Student("4","김연수",random.nextInt(100)+1,random.nextInt(100)+1,random.nextInt(100)+1)); 
		list.add(new Student("6","이승돌",random.nextInt(100)+1,random.nextInt(100)+1,random.nextInt(100)+1));
		
		for(Student student : list){ //기준 대상
			int rank = 1;
			for(Student student2 : list){ //비교 대상
				if(student.getTotal() < student2.getTotal()){
					rank++;
				} else if(student.getTotal()==student.getTotal()) {
					student.setRank(rank);
				}
			}
			student.setRank(rank);
		}
		//오름차순
//		Collections.sort(list,(Student s1,Student s2)->{
//			int result = -1;
//			if(s1.getStudentNo() >= s2.getStudentNo())
//				result = 1;
//			if(s1.getStudentNo() == s2.getStudentNo()) {
//				Collections.sort(list,new ComparatorStudent());
//				result = 0;
//			}
//				return result;
//		});
		Collections.sort(list);
		for(Student student : list)
		{
			System.out.print("[" + student.getStudentNo()+"\t"+student.getStudentNm()+"\t"+student.getTotal() +"\t"+student.getRank()+ "등 ]\n");
		}
		System.out.println("==============================");
		
		Collections.sort(list,new ComparatorStudent());

		for(Student student : list)
		{
			System.out.print("[" + student.getStudentNo()+"\t"+student.getStudentNm()+"\t"+student.getTotal() +"\t"+student.getRank()+ "등 ]\n");
		}
	}
}

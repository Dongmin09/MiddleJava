package kr.or.ddit.Notice;

import java.util.List;
import java.util.Scanner;

import kr.or.ddit.Notice.service.INoticeService;
import kr.or.ddit.Notice.service.NoticeServiceImpl;
import kr.or.ddit.Notice.vo.NoticeVO;

public class NoticeMain {

		private Scanner scan = new Scanner(System.in);
		private INoticeService notiService;
		
		public NoticeMain() {
			notiService = new NoticeServiceImpl();
		}
		
		public void displayMenu() {
			System.out.println();
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println("  === 작 업 선 택 ===");
			System.out.println("  1. 게시판 입력");
			System.out.println("  2. 게시판 삭제");
			System.out.println("  3. 게시판 수정");
			System.out.println("  4. 전체 게시판 출력");
			System.out.println("  5. 게시판 검색.");
			System.out.println("  6. 작업 끝.");
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.print("원하는 작업 선택 >> ");
		}
		
		public void start() {
			int choice;
			do {
				displayMenu();
				choice = scan.nextInt();
				switch (choice) {
				case 1: // 자료 입력
					insertBoard();
					break;
				case 2: // 자료 삭제
					deleteBoard();
					break;
				case 3: // 자료 수정
					updateBoard();
					break;
				case 4: // 전체 자료 출력
					displayBoardAll();
					break;
				case 5: // 자료 검색
					searchBoard();
					break;
				case 6: // 작업 끝
					System.out.println("작업을 마칩니다.");
					break;
				default:
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
				}
			} while (choice != 6);
		}

		private void searchBoard() {
			
			scan.nextLine();
			System.out.println();
			System.out.println("검색할 게시물을 입력하세요.");
			System.out.println("게시물 번호 >>");
			String boardNo = scan.nextLine().trim();
			
			System.out.println("게시물 제목");
			String boardTitle = scan.nextLine().trim();
			
			System.out.println("게시물 작성자");
			String boardWriter = scan.nextLine().trim();
			
			System.out.println("게시물 내용");
			String boardContent = scan.nextLine().trim();
			
			NoticeVO nv = new NoticeVO();
			nv.setBoardNo(boardNo);
			nv.setBoardTitle(boardTitle);
			nv.setBoardWriter(boardWriter);
			nv.setBoardContent(boardContent);
			
			List<NoticeVO> notiList = notiService.searchNoticeList(nv);
			
			System.out.println();
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println(" 게시물번호\t게시물 제목\t게시물 작성자\t\t게시물 내용");
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			
			if(notiList.size() == 0) {
				System.out.println("검색된 게시물이 없습니다.");
			} else {
				for(NoticeVO nv2 : notiList) {
					System.out.println(nv2.getBoardNo() + "\t" + nv2.getBoardTitle() + "\t" + nv2.getBoardWriter() + "\t\t" + nv2.getBoardContent());
				}
			}
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println("검색 끝.");
		}

		private void displayBoardAll() {
			System.out.println();
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println("게시물번호\\t게시물 제목\\t게시물 작성자\\t\\t게시물 내용");
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			
			List<NoticeVO> notiList = notiService.getAllBoardList();
			
			if(notiList.size() == 0) {
				System.out.println(" 출력할 게시물이 없습니다.");
			} else {
				for(NoticeVO nv : notiList) {
					System.out.println(nv.getBoardNo() + "\t" + nv.getBoardTitle() + "\t" + nv.getBoardWriter() + "\t\t" + nv.getBoardContent());
				}
			}
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println(" 출력 끝.");
		}			
		

		private void updateBoard() {

			boolean chk = true;

			String boardNo = "";

			do {
				System.out.println();
				System.out.println("수정할 게시물을 입력하세요.");
				System.out.print("게시물 번호 >> ");

				boardNo = scan.next();

				chk = checkBoard(boardNo);

				if (chk == false) {
					System.out.println("게시물이 " + boardNo + "인 게시물은 존재하지 않습니다.");
					System.out.println("다시 입력해 주세요.");
				}

			} while (chk == false);

			System.out.print("게시물 제목 >> ");
			String boardTitle = scan.next();

			System.out.print("게시물 작성자 >> ");
			String boardWriter = scan.next();

			scan.nextLine(); // 입력버퍼 비우기

			System.out.print("게시물 내용 >> ");
			String boardContent = scan.nextLine();
			
			NoticeVO nv = new NoticeVO();
			nv.setBoardNo(boardNo);
			nv.setBoardTitle(boardTitle);
			nv.setBoardWriter(boardWriter);
			nv.setBoardContent(boardContent);
			
			int cnt = notiService.modifyBoard(nv);
			
			if(cnt > 0) {
				System.out.println(boardNo + "게시물 수정 성공!");
			} else {
				System.out.println(boardNo + "게시물 수정 실패!!!");
			}
		}

		private boolean checkBoard(String boardNo) {
			
			boolean chk = notiService.checkBoard(boardNo);
			
			return chk;
		}

		private void deleteBoard() {
			System.out.println();
			System.out.println("삭제할 게시물 입력하세요.");
			System.out.println("게시물 번호 >>");
			
			String boardNo = scan.next();
			
			int cnt = notiService.removeBoard(boardNo);
			
			if(cnt > 0) {
				System.out.println(boardNo + "게시물 삭제 성공!");
			} else {
				System.out.println(boardNo + "게시물 삭제 실패!!!");
			}
						
		}

		private void insertBoard() {

			boolean chk = false;

			String boardNo = "";

			do {
				System.out.println();
				System.out.println("추가할 회원 정보를 입력하세요.");
				System.out.print("회원 ID >> ");

				boardNo = scan.next();

				chk = checkBoard(boardNo);

				if (chk == true) {
					System.out.println("게시물이 " + boardNo + "인 게시물은 이미 존재합니다.");
					System.out.println("다시 입력해 주세요.");
				}

			} while (chk == true);

			System.out.print("게시물 제목 >> ");
			String boardTitle = scan.next();

			System.out.print("게시물 작성자 >> ");
			String boardWriter = scan.next();

			scan.nextLine(); // 입력버퍼 비우기

			System.out.print("게시물 내용 >> ");
			String boardContent = scan.nextLine();
			
			NoticeVO nv = new NoticeVO();
			nv.setBoardNo(boardNo);
			nv.setBoardTitle(boardTitle);
			nv.setBoardWriter(boardWriter);
			nv.setBoardContent(boardContent);
			
			int cnt = notiService.registerBoard(nv);
			
			if(cnt > 0) {
				System.out.println(boardNo + "게시물 등록 성공!");
			} else {
				System.out.println(boardNo + "게시물 등록 실패!!!");
			}			
		} 
}

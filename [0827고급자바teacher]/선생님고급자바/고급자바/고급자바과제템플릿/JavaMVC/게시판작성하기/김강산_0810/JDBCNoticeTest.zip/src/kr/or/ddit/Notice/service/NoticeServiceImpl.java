package kr.or.ddit.Notice.service;

import java.util.List;

import kr.or.ddit.Notice.dao.INoticeDAO;
import kr.or.ddit.Notice.dao.NoticeDAOImpl;
import kr.or.ddit.Notice.vo.NoticeVO;

public class NoticeServiceImpl implements INoticeService{

	private INoticeDAO notiDao;
	
	public NoticeServiceImpl() {
		notiDao = new NoticeDAOImpl();
	}
	
	@Override
	public int registerBoard(NoticeVO nv) {
		int cnt = notiDao.insertBoard(nv);
		return cnt;
	}

	@Override
	public boolean checkBoard(String boardNo) {
		boolean chk = notiDao.checkBoard(boardNo);
		return chk;
	}

	@Override
	public int modifyBoard(NoticeVO nv) {
		int cnt = notiDao.updateBoard(nv);
		return cnt;
	}

	@Override
	public int removeBoard(String boardNo) {
		int cnt = notiDao.deleteBoard(boardNo);
		return cnt;
	}

	@Override
	public List<NoticeVO> getAllBoardList() {
		List<NoticeVO> notiList = notiDao.getAllBoardList();
		return notiList;
	}

	@Override
	public List<NoticeVO> searchNoticeList(NoticeVO nv) {
		List<NoticeVO> notiList = notiDao.searchBoardList(nv);
		return notiList;
	}

}

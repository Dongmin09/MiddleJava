package kr.or.ddit.Notice.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.management.RuntimeErrorException;

import kr.or.ddit.Notice.vo.NoticeVO;
import kr.or.ddit.util.JDBCUtil3;

public class NoticeDAOImpl implements INoticeDAO {
	
	private static INoticeDAO notiDao;

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public NoticeDAOImpl() {

	}
	
	public static INoticeDAO getInstance() {
		if(notiDao == null) {
			notiDao = new NoticeDAOImpl();
		}
		return notiDao;
	}
	
	@Override
	public int insertBoard(NoticeVO nv) {
		
		int cnt = 0;
		
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = "INSERT INTO mynotice(board_no, board_title, board_writer, board_date, board_content)"
					+ " VALUES(?, ?, ?, sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nv.getBoardNo());
			pstmt.setString(2, nv.getBoardTitle());
			pstmt.setString(3, nv.getBoardWriter());
			pstmt.setString(4, nv.getBoardContent());
			
			cnt = pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("게시판등록 과정중 예외발생!", ex);
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public boolean checkBoard(String boardNo) {
		boolean chk = false;
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = "select count(*) as cnt from mynotice\n "
					+ "where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			
			if(rs.next()) {
				cnt = rs.getInt(cnt);
			}
			
			if(cnt >0) {
				chk = true;
			}
			
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("게시판정보 확인중 예외발생!", ex);
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return chk;
	}

	@Override
	public int updateBoard(NoticeVO nv) {
		
		int cnt = 0;
		
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = " UPDATE mynotice"
					+ " SET board_no = ?"
					+ " , board_title = ?"
					+ " , board_writer = ?"
					+ " , board_content = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, nv.getBoardNo());
			pstmt.setString(2, nv.getBoardTitle());
			pstmt.setString(3, nv.getBoardWriter());
			pstmt.setString(4, nv.getBoardContent());
			
			cnt = pstmt.executeUpdate();
			
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("게시판수정중 예외발생!", ex);
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public int deleteBoard(String boardNo) {
		
		int cnt = 0;
		
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = " delete from mynotice where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);
			
			cnt = pstmt.executeUpdate();
			
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("게시판삭제 과정중 예외발생", ex);
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public List<NoticeVO> getAllBoardList() {
		
		List<NoticeVO> notiList = new ArrayList<NoticeVO>();
		
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = "select * from mynotice";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				NoticeVO nv = new NoticeVO();
				nv.setBoardNo(rs.getString("board_no"));
				nv.setBoardTitle(rs.getString("board_title"));
				nv.setBoardWriter(rs.getString("board_writer"));
				nv.setBoardContent(rs.getString("board_content"));
				
				notiList.add(nv);
				
			}
			System.out.println("◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇◆◇");
			System.out.println("출력 작업 끝...");
			
		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("전체게시판 조회중 예외발생!", ex);
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		
		return notiList;
	}

	@Override
	public List<NoticeVO> searchBoardList(NoticeVO nv) {
		
		List<NoticeVO> notiList = new ArrayList<NoticeVO>();
		
		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = "select * from mynoticer where 1=1 ";
			if(nv.getBoardNo() != null && !nv.getBoardNo().equals("")) {
				sql += " and board_no = ?";
			}
			if(nv.getBoardTitle() != null && !nv.getBoardTitle().equals("")) {
				sql += " and mem_name = ?";
			}
			if(nv.getBoardWriter() != null && !nv.getBoardWriter().equals("")) {
				sql += " and mem_tel = ?";
			}
			if(nv.getBoardContent() != null && !nv.getBoardContent().equals("")) {
				sql += " and mem_addr like '%' || ? || '%' ";
			}
			
			pstmt = conn.prepareStatement(sql);
			
			int index = 1;

			if(nv.getBoardNo() != null && !nv.getBoardNo().equals("")) {
				pstmt.setString(index++, nv.getBoardNo());
			}
			if(nv.getBoardTitle() != null && !nv.getBoardTitle().equals("")) {
				pstmt.setString(index++, nv.getBoardTitle());
			}
			if(nv.getBoardWriter() != null && !nv.getBoardWriter().equals("")) {
				pstmt.setString(index++, nv.getBoardWriter());
			}
			if(nv.getBoardContent() != null && !nv.getBoardContent().equals("")) {
				pstmt.setString(index++, nv.getBoardContent());
			}
			
			rs = pstmt.executeQuery();
			
			NoticeVO mv2 = new NoticeVO();
			mv2.setBoardNo( rs.getString("board_no"));
			mv2.setBoardTitle(rs.getString("board_title"));
			mv2.setBoardWriter(rs.getString("board_writer"));
			mv2.setBoardContent(rs.getString("board_content"));
			
			notiList.add(mv2);
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return notiList;
	}
	
}

package kr.or.ddit.Notice.service;

import java.util.List;

import kr.or.ddit.Notice.vo.NoticeVO;

public interface INoticeService {

	public int registerBoard(NoticeVO nv);
	
	public boolean checkBoard(String boardNo);
	
	public int modifyBoard(NoticeVO nv);
	
	public int removeBoard(String memId);
	
	public List<NoticeVO> getAllBoardList();
	
	public List<NoticeVO> searchNoticeList(NoticeVO mv);
}

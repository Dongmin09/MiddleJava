package border.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import border.vo.BorderVO;
import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.util.JDBCUtill3;

public class BorderDAOImpl implements BorderDAO {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	@Override
	public boolean checkBorder(String borNo) {
		boolean chk = false;
		try {
			conn = JDBCUtill3.getConnection();
			String sql = "select count(*) as cnt from jdbc_board " + " where board_no = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, borNo);

			rs = pstmt.executeQuery();

			int cnt = 0;
			if (rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if (cnt > 0) {
				chk = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원정보 확인 중 예외발생!", e);
		} finally {
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}

		return chk;
	}

	@Override
	public int insertBorder(BorderVO mv) {
		int cnt = 0;
		try {
			conn = JDBCUtill3.getConnection();

			String sql = "INSERT INTO JDBC_BOARD(BOARD_NO,BOARD_TITLE, BOARD_WRITER, BOARD_CONTENT,BOARD_DATE)"
					+ " VALUES (board_seq.nextVal, ?, ?, ?, sysdate)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBorTit());
			pstmt.setString(2, mv.getBorWrit());
			pstmt.setString(3, mv.getBorCon());
			// int값을 리턴한다 select는 excute커리문 말고 업데이트 딜리트는 executeUpdate를 사용해야 한다.
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원등록 과정중 예외발생!", e);
		} finally {
			// 자원반납...
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public List<BorderVO> getAllBoderList() {
		List<BorderVO> memList = new ArrayList<BorderVO>();

		try {
			conn = JDBCUtill3.getConnection();

			String sql = "select * from JDBC_BOARD";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				BorderVO mv = new BorderVO();
				mv.setBorNo(rs.getNString("BOARD_NO"));
				mv.setBorTit(rs.getNString("BOARD_TITLE"));
				mv.setBorWrit(rs.getNString("BOARD_WRITER"));
				mv.setBorCon(rs.getNString("BOARD_CONTENT"));

				memList.add(mv);

			}

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("전체회원조회 과정중 예외발생!", e);
		} finally {
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}
		return memList;
	}

	@Override
	public int deleteBorder(String borNo) {
		int cnt = 0;
		try {
			conn = JDBCUtill3.getConnection();

			String sql = " delete from JDBC_BOARD where BOARD_NO = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, borNo);
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("글 삭제 과정중 예외발생!", e);
		} finally {
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public int modifyBorder(BorderVO mv) {
		int cnt = 0;
		try {
			conn = JDBCUtill3.getConnection();
			String sql = " UPDATE jdbc_board\n" + "    SET\n" + "         board_title = ? \n"
					+ "        ,board_writer = ? \n" + "        ,board_content = ? \n" + "	 WHERE \n"
					+ "    board_no =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBorTit());
			pstmt.setString(2, mv.getBorWrit());
			pstmt.setString(3, mv.getBorCon());
			pstmt.setString(4, mv.getBorNo());
			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("회원수정 과정중 예외발생!", e);
		} finally {
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public List<BorderVO> searchBorList(BorderVO mv) {
		List<BorderVO> boardList = new ArrayList<BorderVO>();
		try {
			conn = JDBCUtill3.getConnection();
			String sql = "select * from jdbc_board where 1=1";
			if(mv.getBorNo() != null&& !mv.getBorNo().equals("")) {
				sql += "and board_no = ?";
			}
			if(mv.getBorTit()!= null&& !mv.getBorTit().equals("")) {
				sql += "and board_title = ?";
			}
			if(mv.getBorWrit() != null&& !mv.getBorWrit().equals("")) {
				sql += "and board_writer = ?";
			}
			if(mv.getBorCon() != null&& !mv.getBorCon().equals("")) {
				sql += "and board_content like '%' || ? || '%' ";
			}
			
			pstmt = conn.prepareStatement(sql);
			int index = 1;
			if(mv.getBorNo() != null&& !mv.getBorNo().equals("")) {
				pstmt.setString(index++, mv.getBorNo());
			}
			if(mv.getBorTit() != null&& !mv.getBorTit().equals("")) {
				pstmt.setString(index++, mv.getBorTit());
			}
			if(mv.getBorWrit() != null&& !mv.getBorWrit().equals("")) {
				pstmt.setString(index++, mv.getBorWrit());
			}
			if(mv.getBorCon() != null&& !mv.getBorCon().equals("")) {
				pstmt.setString(index++, mv.getBorCon());
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BorderVO mv1 = new BorderVO();
				mv1.setBorNo(rs.getString("board_no"));
				mv1.setBorTit(rs.getString("board_title"));
				mv1.setBorWrit(rs.getString("board_writer"));
				mv1.setBorCon(rs.getString("board_content"));
				mv1.setRegDate(rs.getString("board_date"));
				
				boardList.add(mv1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			JDBCUtill3.close(conn, stmt, pstmt, rs);
		}
		return boardList;
	}

}

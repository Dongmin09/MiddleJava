package kr.or.ddit.member.service;

import java.util.List; 

import kr.or.ddit.member.dao.BoardDAO;
import kr.or.ddit.member.dao.BoardDAOImpl;
import kr.or.ddit.member.vo.BoardVO;

public class BoardServiceImpl implements BoardService {
	private static BoardService boardService;
	private BoardDAO boardDAO;

	private BoardServiceImpl() {
		boardDAO = BoardDAOImpl.getInstance();
	}

	public static BoardService getInstance() {
		if(boardService == null) {
			boardService = new BoardServiceImpl();
		}
		return boardService;
	}
	@Override
	public int write(BoardVO bv) {
		int cnt = boardDAO.write(bv);
		return cnt;
	}

	@Override
	public boolean check(String boardNo) {
		boolean chk = boardDAO.check(boardNo);
		return chk;
	}

	@Override
	public int modify(BoardVO bv) {
		int cnt = boardDAO.update(bv);
		return cnt;
	}

	@Override
	public int remove(String boardNo) {
		int cnt = boardDAO.delete(boardNo);
		return cnt;
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		List<BoardVO> boardList = boardDAO.getAllBoardList();
		return boardList;
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO bv) {
		List<BoardVO> boardList = boardDAO.searchBoardList(bv);
		
		return boardList;
	}
	
	
		 
		
	}



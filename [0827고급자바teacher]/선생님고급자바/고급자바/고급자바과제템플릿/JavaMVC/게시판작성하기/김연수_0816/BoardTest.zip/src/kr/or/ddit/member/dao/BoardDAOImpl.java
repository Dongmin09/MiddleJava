package kr.or.ddit.member.dao;

import java.sql.Connection;    
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.or.ddit.member.vo.BoardVO;
import kr.or.ddit.util.JDBCUtil3;
import kr.or.ddit.util.MyBatisUtil;

public class BoardDAOImpl implements BoardDAO {
	
	private static BoardDAO boardDao;

	private SqlSession sqlSession;
	
	private BoardDAOImpl() {
		sqlSession = MyBatisUtil.getInstance(true);
	}
	
	public static BoardDAO getInstance() {
		if(boardDao == null) {
			boardDao = new BoardDAOImpl();
		}
		return boardDao;
	}
	@Override
	public int write(BoardVO bv) {

		int cnt = sqlSession.insert("member.write", bv);
		
		return cnt;
	}

	@Override
	public boolean check(String boardNo) {


		boolean chk = false;
		
		int cnt = sqlSession.selectOne("member.check", boardNo);
			
			if(cnt > 0) {
				chk = true;
			}
			
		return chk;
	}


	@Override
	public int update(BoardVO bv) {

		int cnt = sqlSession.update("member.update", bv);

		return cnt;
		
	}

	@Override
	public int delete(String boardNo) {

		int cnt = sqlSession.delete("member.delete", boardNo);

		return cnt;
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		
		List<BoardVO> boardList = sqlSession.selectList("member.boardAllList");
		
		return boardList;
		
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO bv) {

		List<BoardVO> boardList = sqlSession.selectList("member.searchBoardList", bv);
		
		return boardList;
		
}
}


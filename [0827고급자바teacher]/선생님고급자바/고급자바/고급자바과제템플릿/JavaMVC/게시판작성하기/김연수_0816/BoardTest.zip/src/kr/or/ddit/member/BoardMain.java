package kr.or.ddit.member;
import java.sql.Connection;   
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Scanner;

import kr.or.ddit.member.service.BoardService;
import kr.or.ddit.member.service.BoardServiceImpl;
import kr.or.ddit.member.vo.BoardVO;
import kr.or.ddit.util.JDBCUtil3;

public class BoardMain {



	private Scanner scan = new Scanner(System.in); 
	private BoardService boardService;

	public BoardMain() { 
		boardService = BoardServiceImpl.getInstance();
	}
	/**
	 * 메뉴를 출력하는 메서드 
	 */
	public void displayMenu(){ 
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 새 글 작성");
		System.out.println("  2. 삭제");
		System.out.println("  3. 수정");
		System.out.println("  4. 전체 목록 출력");
		System.out.println("  5. 게시글 검색.");
		System.out.println("  6. 작업 끝.");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}

	/**
	 * 프로그램 시작메서드
	 */
	public void start(){ 
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch(choice){
			case 1 :  // 새 글 작성
				write();
				break;
			case 2 :  //  삭제
				delete();
				break;
			case 3 :  //  수정
				update();
				break;
			case 4 :  // 전체 목록 출력
				displayAll();
				break;
			case 5 :  // 게시글 검색
				search();
				break;
			case 6 :  // 작업 끝
				System.out.println("작업을 마칩니다.");
				break;
			default :
				System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=6);
	}
	/*
	 * 게시글 검색 메서드
	 */
	private void search() {
		
		scan.nextLine(); // 입력 버퍼 비우기
		System.out.println();
		System.out.println("검색할 게시글 정보를 입력하세요.");
		System.out.print("게시글 번호 >> ");
		String boardNo = scan.nextLine(); //trim() -> 공백처리
		
		System.out.print("게시글 제목 >> ");
		String boardTitle = scan.nextLine().trim();
		
		System.out.print("작성자 이름 >> ");
		String writer = scan.nextLine().trim(); 
		
		System.out.print("글 내용 >> ");
		String cont = scan.nextLine().trim();
		
		BoardVO bv = new BoardVO();
		bv.setBoardNo(boardNo);
		bv.setBoardTitle(boardTitle);
		bv.setWriter(writer);
		bv.setCont(cont);
		
		List<BoardVO> boardList = boardService.searchBoardList(bv);
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t\t작성자\t\t내용");
		System.out.println("--------------------------------------------------------------------------");

		if(boardList.size() == 0) {
			System.out.println("검색된 회원정보가 없습니다.");
		}else {
			for(BoardVO bv2 : boardList) {
				System.out.println(bv2.getBoardNo() + "\t\t" + bv2.getBoardTitle()+"\t"
						+bv2.getWriter() + "\t" +  bv2.getCont());				
			}
		}
		System.out.println("------------------------------------------------");
		System.out.println("검색 끝.");

	}
	
	/*
	 	 전체 회원 정보를 출력하는 메서드
	 */
	private void displayAll() { 
		System.out.println();
		System.out.println("--------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t\t작성자\t\t작성날짜");
		System.out.println("--------------------------------------------------------------------------");

		List<BoardVO> boardList = boardService.getAllBoardList();

		if(boardList.size() == 0) {
			System.out.println("출력할 회원정보가 없습니다.");
		}else {
			for(BoardVO bv : boardList) {
				System.out.println(bv.getBoardNo() + "\t" + bv.getBoardTitle()+"\t"
						+bv.getWriter()+"\t\t" + bv.getCont());				
			}
		}
		System.out.println("------------------------------------------------");
		System.out.println("출력 끝.");

	}

	/*
	 	회원 정보를 삭제하는 메서드
	 */
	private void delete() {
		System.out.println();
		System.out.println("삭제할 게시글 정보를 입력하세요.");
		System.out.print("번호 >> ");

		String boardNo = scan.next();


		int cnt = boardService.remove(boardNo);

		if(cnt > 0 ) {
			System.out.println(boardNo + " 회원 정보 삭제 완료.");
		} else {
			System.out.println(boardNo + " 회원 정보 삭제 실패.");
		}
	}
	/*
	 	회원 정보를 수정하는 메서드
	 */
	private void update() {
		
		boolean chk = false;
		
		String boardNo = ""; 

		do {
			System.out.println();
			System.out.println("수정할 게시글 정보를 입력하세요.");
			System.out.print("번호 >> ");

			boardNo = scan.next();

			chk = checkMember(boardNo);

			if(chk == false) {
				System.out.println("게시글 번호가 " + boardNo + "인 게시글은 존재하지 않습니다.");
				System.out.println("다시 입력해 주세요.");
			}

		} while (chk == false);

		System.out.print("제목 >> ");
		String boardTitle = scan.next();

		System.out.print("작성자 >> ");
		String writer = scan.next();

		scan.nextLine(); // 입력 버퍼 비우기
		System.out.print("내용 >> ");
		String cont = scan.nextLine();

		BoardVO bv = new BoardVO();
		bv.setBoardNo(boardNo);
		bv.setBoardTitle(boardTitle);
		bv.setWriter(writer);
		bv.setCont(cont);

		int cnt = boardService.modify(bv);

		if(cnt > 0 ) {
			System.out.println(boardNo + " 게시글 수정 완료.");
		} else {
			System.out.println(boardNo + " 게시글 수정 실패.");
		}
	}

	/*
	 * 새글 작성
	 */
	private void write() { 

		System.out.print("제목 >> ");
		String boardTitle = scan.next();

		System.out.print("작성자 >> ");
		String writer = scan.next();

		scan.nextLine(); // 입력 버퍼 비우기
		System.out.print("내용 >> ");
		String cont = scan.nextLine();

		BoardVO bv = new BoardVO();
		bv.setBoardTitle(boardTitle);
		bv.setWriter(writer);
		bv.setCont(cont);

		int cnt = boardService.write(bv);

		if(cnt > 0 ) {
			System.out.println(" 게시글 등록 완료.");
		} else {
			System.out.println(" 게시글 등록 실패.");
		}

	}
	/*
	 	회원 ID를 이용하여 회원이 존재하는지 알려주는 메서드
	 	@param memId
	 	@return 회원이 존재하면 true, 없으면 false
	 */
	private boolean checkMember(String boardNo) {

		boolean chk = boardService.check(boardNo);

		return chk;
	}

	public static void main(String[] args) {
		BoardMain boardObj = new BoardMain();
		boardObj.start();
	}


}







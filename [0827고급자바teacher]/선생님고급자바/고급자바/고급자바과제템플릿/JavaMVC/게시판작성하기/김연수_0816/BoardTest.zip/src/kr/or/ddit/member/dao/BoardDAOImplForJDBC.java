package kr.or.ddit.member.dao;

import java.sql.Connection;    
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.member.vo.BoardVO;
import kr.or.ddit.util.JDBCUtil3;

public class BoardDAOImplForJDBC implements BoardDAO {
	
	private static BoardDAO boardDao;

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private BoardDAOImplForJDBC() {
	}
	
	public static BoardDAO getInstance() {
		if(boardDao == null) {
			boardDao = new BoardDAOImplForJDBC();
		}
		return boardDao;
	}
	@Override
	public int write(BoardVO bv) {

		int cnt = 0;

		try {
			conn = JDBCUtil3.getConnection();

			String sql = "INSERT INTO jdbc_board (\n" + 
					"    board_no,\n" + 
					"    board_title,\n" + 
					"    board_writer,\n" + 
					"    board_date,\n" + 
					"    board_content\n" + 
					") VALUES (\n" + 
					"    board_seq.nextVal,\n" + 
					"    ?,\n" + 
					"    ?,\n" + 
					"    sysdate," +
					"    ?)\n" ; 

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoardTitle());
			pstmt.setString(2, bv.getWriter());
			pstmt.setString(3, bv.getCont());

			cnt = pstmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원 등록 과정중 예외 발생", ex);
		} finally {
			// 자원반납 ....
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public boolean check(String boardNo) {


		boolean chk = false;

		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = " select count(*) as cnt from jdbc_board\n" + 
					" where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if(cnt > 0) {
				chk = true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			
		}finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return chk;
	}


	@Override
	public int update(BoardVO mv) {

		int cnt = 0;

		try {
			conn = JDBCUtil3.getConnection();
			
			String sql = " UPDATE jdbc_board\n" + 
					"    SET\n" + 
					"         board_title = ? \n" + 
					"        ,board_writer = ? \n" + 
					"        ,board_content = ? \n" + 
					"	 WHERE \n" + 
					"    board_no =?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBoardTitle());
			pstmt.setString(2, mv.getWriter());
			pstmt.setString(3, mv.getCont());
			pstmt.setString(4, mv.getBoardNo());
			
			cnt = pstmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("회원 수정 과정중 예외 발생", ex);

		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public int delete(String boardNo) {

		int cnt = 0;

		try {
			conn = JDBCUtil3.getConnection();

			String sql = "delete from jdbc_board where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  boardNo);

			cnt = pstmt.executeUpdate();

		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("삭제 과정중 예외 발생", ex);

		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return cnt;
	}

	@Override
	public List<BoardVO> getAllBoardList() {

		List<BoardVO> boardList = new ArrayList<BoardVO>();
		try {
			conn = JDBCUtil3.getConnection();

			String sql = "select * from jdbc_board";

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			while(rs.next()) {
				BoardVO bv = new BoardVO();
				bv.setBoardNo(rs.getString("board_no"));
				bv.setBoardTitle(rs.getString("board_title"));
				bv.setWriter(rs.getString("board_writer"));
				bv.setCont(rs.getString("board_content"));
				bv.setDate(rs.getString("board_date").substring(0, 10));
				
				boardList.add(bv);
			}


		} catch (SQLException ex) {
			ex.printStackTrace();
			throw new RuntimeException("전체 회원 조회중 예외 발생", ex);

		} finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return boardList;
	}

	@Override
	public List<BoardVO> searchBoardList(BoardVO bv) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		try {
			conn = JDBCUtil3.getConnection();
			String sql = "select * from jdbc_board where 1=1";
			if(bv.getBoardNo() != null&& !bv.getBoardNo().equals("")) {
				sql += "and board_no = ?";
			}
			if(bv.getBoardTitle() != null&& !bv.getBoardTitle().equals("")) {
				sql += "and board_title = ?";
			}
			if(bv.getWriter() != null&& !bv.getWriter().equals("")) {
				sql += "and board_writer = ?";
			}
			if(bv.getCont() != null&& !bv.getCont().equals("")) {
				sql += "and board_content like '%' || ? || '%' ";
			}
			
			pstmt = conn.prepareStatement(sql);
			int index = 1;
			if(bv.getBoardNo() != null&& !bv.getBoardNo().equals("")) {
				pstmt.setString(index++, bv.getBoardNo());
			}
			if(bv.getBoardTitle() != null&& !bv.getBoardTitle().equals("")) {
				pstmt.setString(index++, bv.getBoardTitle());
			}
			if(bv.getWriter() != null&& !bv.getWriter().equals("")) {
				pstmt.setString(index++, bv.getWriter());
			}
			if(bv.getCont() != null&& !bv.getCont().equals("")) {
				pstmt.setString(index++, bv.getCont());
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardVO bv1 = new BoardVO();
				bv1.setBoardNo(rs.getString("board_no"));
				bv1.setBoardTitle(rs.getString("board_title"));
				bv1.setWriter(rs.getString("board_writer"));
				bv1.setCont(rs.getString("board_content"));
				bv1.setDate(rs.getString("board_date"));
				
				boardList.add(bv1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			JDBCUtil3.close(conn, stmt, pstmt, rs);
		}
		return boardList;
	}

}

